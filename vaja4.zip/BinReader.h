//
// Created by ALEX on 27. 05. 2020.
//

#ifndef VAJA4_BINREADER_H
#define VAJA4_BINREADER_H

#include <iostream>
#include <fstream>
using namespace std;

class BinReader {
public:
    ifstream file;
    int k;
    char x;
    float f;

    BinReader(const string& path);

    char readByte();
    bool readBit();
    int readInt();
    float readFloat();
};


#endif //VAJA4_BINREADER_H
