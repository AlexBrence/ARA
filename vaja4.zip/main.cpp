#include <iostream>
#include <vector>
#include <algorithm>
#include <cmath>
#include <unordered_map>
#include "BinWriter.h"
#include "BinReader.h"

using namespace std;



bool preveriSlovar(vector<string> vec, string T, char C) {
    string searched = T += C;

    return (find(vec.begin(), vec.end(), searched) != vec.end());
}

void decimalToBinary(int n, vector<int>& binary, int binSize) {
    long long binaryNumber = 0;
    int remainder, i = 1;

    while (n!=0)
    {
        remainder = n%2;
        binary[binSize--] = remainder;
        n /= 2;
        binaryNumber += remainder*i;
        i *= 10;
    }
}

int main(int argc, const char* argv[]) {

    /*if (argc != 4)
        return -1;


    if (argv[1][0] == 'c') {
  */

    //int maxVelikost = argv[2][0];

    int maxVelikost = 300;
    double numOfBits = ceil(log2(maxVelikost + 1));
    vector<int> binary (numOfBits, 0);
    int index = 256;    // Za nize, ki jih ni v abecedi
    string T = "";

    // Nastavim 256 znakov ASCII
    vector<string> vec (maxVelikost, "");
    for (int i = 0; i < 256; i++) {
        string ch = "";
        ch += (char) i;
        vec[i] = ch;
    }



    BinReader br(R"(C:\Users\ALEX\CLionProjects\ARA\vaja4\primeriVhoda\alice.txt)");
    BinWriter bw(R"(C:\Users\ALEX\CLionProjects\ARA\vaja4\out.bin)");


    // br.readByte();
    while (!br.file.eof()) {
        char C = br.readByte();
        cout << C;

        // Preveri, če je T += C v slovarju
        if (preveriSlovar(vec, T, C)) {
            T += C;
        } else {
            // Index novega niza v iz dec v bin
            decimalToBinary(index, binary, binary.size() - 1);

            // Zapišem v datoteko
            for (const auto &elt : binary) {
                bw.writeInt(elt);
            }
            vec.push_back(T + C);
            index++;
            T = C;
        }
    }

    br.file.close();

    /*// COMPRESS
    }
    else if (argv[1][0] == 'd') {
        // DECOMPRESS
    }
    else {
        return -1;
    }
*/

    return 0;
}
