#include <iostream>
#include <vector>
#include <algorithm>
#include <cmath>
#include "BinWriter.h"
#include "BinReader.h"

using namespace std;



bool preveriSlovar(vector<string> vec, string T, string C) {
    string searched = T += C;

    cout << "\tT+C:" << searched << "\tvSlovarju?:" << (find(vec.begin(), vec.end(), searched) != vec.end());
    return (find(vec.begin(), vec.end(), searched) != vec.end());
}

void decimalToBinary(int n, vector<int>& binary, int binSize) {
    long long binaryNumber = 0;
    int remainder, i = 1;

    while (n != 0) {
        remainder = n % 2;
        binary[binSize--] = remainder;
        n /= 2;
        binaryNumber += remainder*i;
        i *= 10;
    }
}


int findIndex(vector<string> vec, const string &T, const int &index) {
    for (int i = 0; i < index; i++) {
        if (vec[i] == T)
            return i;
    }
}


void nastaviSlovar(vector<string> &vec) {
    // Nastavim 256 znakov ASCII
    for (int i = 0; i < 256; i++) {
        string ch = "";
        ch += (char) i;
        vec[i] = ch;
    }

}


int main(int argc, const char* argv[]) {

    /*if (argc != 4)
        return -1;
  */

    //int maxVelikost = argv[2][0];
    // Za izračun kompresijskega razmerja
    int steviloBitovIzhod = 0;
    int steviloZnakov = 0;

    int maxVelikost = 256 * 2;
    double steviloBitovIzracun = 5;//ceil(log2(maxVelikost + 1));
    int index = 256;    // Za nize, ki jih ni v abecedi
    string T = "";

    vector<string> vec(maxVelikost, "");
    if (argv[1][0] == 'c') {
        nastaviSlovar(vec);

        BinReader br(R"(C:\Users\ALEX\CLionProjects\ARA\vaja4\primeriVhoda\test.txt)");
        BinWriter bw(R"(C:\Users\ALEX\CLionProjects\ARA\vaja4\out.bin)");

        while (br.file.peek() != EOF) {
            string C = "";
            C += br.readByte();
            steviloZnakov++;
            cout << "VHOD:" << C << "\tPR.NIZ:" << T;

            // Preveri, če je T += C v slovarju
            if (preveriSlovar(vec, T, C)) {
                cout << endl;
                T += C;
            }
            else {
                // Index od T iz dec v bin
                int indexT = findIndex(vec, T, index);
                vector<int> binary(steviloBitovIzracun, 0);
                decimalToBinary(indexT, binary, binary.size() - 1);
                steviloBitovIzhod++;

                cout << "\tIZHOD:" << T << "(" << indexT << ")";


                // Zapišem v datoteko
                cout << "\tBINARNI:";

                for (const auto &elt : binary) {
                    bw.writeBit(elt);
                    cout << elt;
                }
                cout << "\tNOVA BESEDA:" << T + C << "(" << index << ")" << endl;
                //bw.writeByte(bw.x);


                // Dodaj niz v slovar
                vec.push_back(T + C);
                index++;
                T = C;
            }
        }
        cout << endl << "KOMPRESIJSKO RAZMERJE: " << (steviloZnakov * 8) / (steviloBitovIzhod * steviloBitovIzracun);

        br.file.close();

    }
    else if (argv[1][0] == 'd') {
        // DECOMPRESS
            // Če index preseže max velikost slovarja
            if (index > maxVelikost) {
                nastaviSlovar(vec);
                index = 256;
            }
    }
    else {
        return -1;
    }

    return 0;
}
