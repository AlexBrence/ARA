//
// Created by ALEX on 27. 05. 2020.
//

#ifndef VAJA4_BINWRITER_H
#define VAJA4_BINWRITER_H

#include <iostream>
#include <fstream>
using namespace std;

class BinWriter {
public:
    ofstream file;
    char x;
    int k;

    BinWriter(const string &path);
    ~BinWriter();

    void writeByte(const char &x);
    void writeBit(const bool &b);
    void writeInt(const int &y);
    void writeFloat(const float &f);
};


#endif //VAJA4_BINWRITER_H
