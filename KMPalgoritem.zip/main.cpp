#include <iostream>
#include <sstream>
#include <fstream>

using namespace std;

ofstream out;

string inputText(const string &pot) {
	ifstream input(pot);
	stringstream sstream;

	if (!input.is_open()) {
		return string();
	}
	
	sstream << input.rdbuf();
	return sstream.str();

}

void izpis_KMPnext(const int* polje, int len) {
	for (int i = 0; i < len; ++i) {
		out << polje[i] << ' ';
	}
	out << endl;
}

void KMPtabela(const string& vzorec, int v, int shrani[]) {
    int dolzina = 0;
    shrani[0] = -1;

    for (int i = 1; i < v; i++) {
        if (vzorec[i] == vzorec[dolzina]) {
            dolzina++;
            shrani[i] = dolzina;
        } else {
            if (dolzina != 0)
                dolzina = shrani[dolzina - 1];
            else
                shrani[i] = 0;
        }
    }

    izpis_KMPnext(shrani, v);

    cout << endl << endl;
}


void KMP(const string& text, const string& vzorec) {
    int v = vzorec.size();
    int t = text.size();
    bool vsebuje = false;

    int shrani[v];

    KMPtabela(vzorec, v, shrani);

    int indexT = 0;
    int indexV = 0;

    while (indexT < t) {
        if (vzorec[indexV] == text[indexT]) {
            indexT++;
            indexV++;
        }
        if (indexV == v) {
            out << "Vzorec '" << vzorec << "' se nahaja na indexu " << indexT-indexV << endl;
            indexV = shrani[indexV-1];
            vsebuje = true;
        } else if (indexT < t && vzorec[indexV] != text[indexT]) {
            if (indexV != 0)
                indexV = shrani[indexV-1];
            else
                indexT = indexT + 1;
        }
    }
    if (!vsebuje) {
        out << "Vzorca ni v tekstu!" << endl << endl;
    }

}

int main(int argc, const char *const argv[]) {
	if (argc != 3) {
		return -1;
	}

	string text = inputText(argv[2]);
	string vzorec = argv[1];
	out.open("out.txt");

	if (!out) {
		return -2;
	}

	KMP(text, vzorec);
	return 0;
}