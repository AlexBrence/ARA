#include <iostream>
#include <sstream>
#include <fstream>
#include <vector>
using namespace std;

ofstream out;

string inputText(const string &pot) {
	ifstream input(pot);
	stringstream sstream;

	if (!input.is_open()) {
		return string();
	}
	
	sstream << input.rdbuf();
	return sstream.str();
}

void izpis_BCHnext(const vector<uint>& polje, const int &len) {
	for (int i = 0; i < len; ++i) {
		out << polje[i] << ' ';
	}
	out << endl;
}

void BCHtabela(const string &vzorec, const int &m, vector<uint>& BCH) {
    for (int i = 0; i < m; i++) {
        for (int j = 0; j < i; j++) {
            if (vzorec[i] == vzorec[j]) {
                BCH[vzorec[j]] = m - i;
                break;
            }
            else if (j == (i-1)) {
                BCH[vzorec[i]] = m - i;
            }
        }
    }

}

void BCH(const string& text, const string& vzorec) {
    int m = vzorec.size();
    vector<uint> BCH(256, m+1);
    BCHtabela(text, m, BCH);
    vector<uint> ujemanja;

    int i;
    int j = 0;

    // Dokler vzorec ne gre dlje od zadnje črke texta
    while ((j+m) < text.size()) {
        for (i = 0; i < m; i++, j++) {
            if (vzorec[i] != text[j]) {
                i = 0;
                if ((j + m) > text.size())
                    break;
                j += BCH[text[j + m - i]];
            }
        }
        // Če je popolno ujemanje
        ujemanja.emplace_back(j - m);
        j += m;
    }

    izpis_BCHnext(BCH, 256);
    izpis_BCHnext(ujemanja, ujemanja.size());

}

int main(int argc, const char *const argv[]) {
	if (argc != 3) {
		return -1;
	}

	string text = inputText(argv[2]);
	string vzorec = argv[1];
	out.open("out.txt");

	if (!out) {
		return -2;
	}

	BCH(text, vzorec);
	return 0;
}