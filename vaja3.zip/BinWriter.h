//
// Created by alex on 5/18/20.
//

#ifndef VAJA3_BINWRITER_H
#define VAJA3_BINWRITER_H

#include <iostream>
#include <fstream>
using namespace std;

class BinWriter {
public:
    ofstream file;
    char x;
    int k;

    BinWriter(const string &path);
    ~BinWriter();

    void writeByte(const char &x);
    void writeBit(const bool &b);
    void writeInt(const int &y);
    void writeFloat(const float &f);
};


#endif //VAJA3_BINWRITER_H
