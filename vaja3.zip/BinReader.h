//
// Created by alex on 5/18/20.
//

#ifndef VAJA3_BINREADER_H
#define VAJA3_BINREADER_H

#include <iostream>
#include <fstream>
using namespace std;

class BinReader {
public:
    ifstream file;
    int k;
    char x;
    float f;

    BinReader(const string& path);

    char readByte();
    bool readBit();
    int readInt();
    float readFloat();
};


#endif //VAJA3_BINREADER_H
