#include <iostream>
#include <vector>
#include <algorithm>
#include <sstream>
#include "BinReader.h"
#include "BinWriter.h"

using namespace std;

vector<uint> seznam(255, 0);
vector<int> indeksi(255);


int deli(int dno, int vrh) {
    int pe = seznam[dno];
    int l = dno;
    int d = vrh;
    while (l < d) {
        while (seznam[l] <= pe && l < vrh)
            l++;
        while (seznam[d] >= pe && d > dno)
            d--;
        if (l < d) {
            swap(seznam[l], seznam[d]);
            swap(indeksi[l], indeksi[d]);
        }
    }
    swap(seznam[dno], seznam[d]);
    swap(indeksi[dno], indeksi[d]);
    return d;
}


void hitroUredi (int dno, int vrh) {
    if (dno < vrh) {
        int j = deli(dno, vrh);
        hitroUredi(dno, j-1);
        hitroUredi(j+1, vrh);
    }
}


int main(int argc, const char *argv[]) {
    if (argc != 3)
        return -1;


    if (argv[1][0] == 'c') {
        BinReader br(argv[2]);  // Sprobano za "/home/alex/Documents/ARA/vaja3/alice.txt"

        // Nastavim vektor indeksov 0-255
        for (int i = 0; i < 255; i++) {
            indeksi[i] = i;
        }

        // Naredim, uredim seznam verjetnosti
        while (!br.file.eof()) {
            int tmp = (int) br.readByte();   // V ASCII
            seznam[tmp - 1]++;
        }
        hitroUredi(0, seznam.size() - 1);
        reverse(seznam.begin(), seznam.end());

        br.file.close();
    }
    else if (argv[1][0] == 'd') {
        // Decompress
    }
    else {
        return -1;
    }

    return 0;
}
