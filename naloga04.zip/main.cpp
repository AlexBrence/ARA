#include <iostream>
#include <vector>
#include <algorithm>
#include <cmath>
#include "BinWriter.h"
#include "BinReader.h"

using namespace std;



bool preveriSlovar(vector<string> vec, string T, string C) {
    string searched = T += C;

    cout << "\tT+C:" << searched << "\tvSlovarju?:" << (find(vec.begin(), vec.end(), searched) != vec.end());
    return (find(vec.begin(), vec.end(), searched) != vec.end());
}

/*
vector<int> decimalToBinary(int n, int binSize) {
    vector<int> binary(binSize, 0);
    long long binaryNumber = 0;
    int remainder, i = 1;

    while (n != 0) {
        remainder = n % 2;
        binary[--binSize] = remainder;
        n /= 2;
        binaryNumber += remainder*i;
        i *= 10;
    }
    return binary;
}
*/

void decToBin(int n, int*& binArr, int binSize) {
    long long binaryNumber = 0;
    int remainder, i = 1;

    while (n != 0) {
        remainder = n % 2;
        binArr[binSize--] = remainder;
        n /= 2;
        binaryNumber += remainder*i;
        i *= 10;
    }

}

int findIndex(vector<string> vec, const string &T, const int &index) {
    for (int i = 0; i < index; i++) {
        if (vec[i] == T)
            return i;
    }
}


void nastaviSlovar(vector<string> &vec, bool izprazniSlovar) {
    if (izprazniSlovar) {
        vec.clear();
    }
    // Nastavim 256 znakov ASCII
    for (int i = 0; i < 256; i++) {
        string ch = "";
        ch += (char) i;
        vec[i] = ch;
    }

}


int binToDec(int n) {
    int num = n;
    int dec_value = 0;

    // Initializing base value to 1, i.e 2^0
    int base = 1;

    int temp = num;
    while (temp) {
        int last_digit = temp % 10;
        temp = temp / 10;

        dec_value += last_digit * base;

        base = base * 2;
    }

    return dec_value;
}


int main(int argc, const char* argv[]) {

    if (argc != 4)
        return -1;


    int maxVelikost = stoi(argv[2]);

    // Za izračun kompresijskega razmerja
    int steviloBitovIzhod = 0;
    int steviloZnakov = 0;

    double steviloBitovIzracun = ceil(log2(maxVelikost + 1));
    int index = 256;    // Za nize, ki jih ni v slovarju
    int *binArr = new int[(int)steviloBitovIzracun];

    vector<string> slovar(maxVelikost, "");
    if (argv[1][0] == 'c') {
        nastaviSlovar(slovar, false);
        string T = "";

        BinReader br(argv[3]);
        cout << argv[3];
        BinWriter bw("/home/alex/Desktop/naloga04/out.bin");

        while (br.file.peek() != EOF) {
            string C = "";
            C += br.readByte();
            steviloZnakov++;
            cout << "VHOD:" << C << "\tPR.NIZ:" << T;

            // Preveri, če je T += C v slovarju
            if (preveriSlovar(slovar, T, C)) {
                cout << endl;
                T += C;
            }
            else {
                // Index od T iz dec v bin
                int indexT = findIndex(slovar, T, index);
                decToBin(indexT, binArr, (int) steviloBitovIzracun - 1);
                steviloBitovIzhod++;

                cout << "\tIZHOD:" << T << "(" << indexT << ")";

                // Zapišem v datoteko
                cout << "\tBINARNI:";

                for (int i = 0; i < steviloBitovIzracun; i++) {
                    cout << binArr[i];
                    bw.writeBit(binArr[i]);
                }
                cout << "\tNOVA BESEDA:" << T + C << "(" << index << ")" << endl;


                // Dodaj niz v slovar
                slovar.push_back(T + C);
                index++;
                T = C;
            }
        }
        cout << endl << "KOMPRESIJSKO RAZMERJE: " << (steviloZnakov * 8) / (steviloBitovIzhod * steviloBitovIzracun);
        br.file.close();
    }
    else if (argv[1][0] == 'd') {
        nastaviSlovar(slovar, false);
        BinReader br(argv[3]);
        BinWriter bw("/home/alex/Desktop/naloga04/out_d.bin");
        string T = "";
        string izhod = "";
        string P = "";

        string strToIndex;
        int indexT;
        while (br.file.peek() != EOF) {
            string C = "";

            // Če index preseže max velikost slovarja
            if (index > maxVelikost) {
                nastaviSlovar(slovar, true);
                index = 256;
            }

            // Vhod dam v decimal
            strToIndex = "";
            for (int i = 0; i < steviloBitovIzracun; i++) {
                strToIndex += to_string(br.readBit());
            }
            indexT = binToDec(std::stoi(strToIndex));

            // Preveri robni primer
            if (index < indexT) {
                C += P + P[0];
                slovar.emplace_back(C);
                index++;
            }
            T = slovar[indexT];

            cout << "VHOD:" << strToIndex << "(" << indexT << ") ";
            cout << "PR.NIZ:" << P << " TREN.IZHOD:" << T;

            C += T[0] + P;
            izhod += C;
            cout << " TR.NIZ:" << P + C;
            cout << "NOVA BES.:";

            if (preveriSlovar(slovar, P, C)) {
                cout << " CEL.IZHOD:" << izhod;
            }
            else {
                slovar.emplace_back(C);
                cout << P + C << "(" << index << ")";
                index++;
            }
            P = T;

            // Za vpis v datoteko
            decToBin(indexT, binArr, (int)steviloBitovIzracun);
            for (int i = 0; i < steviloBitovIzracun; i++) {
                bw.writeBit(binArr[i]);
            }
            cout << endl;
        }


    }
    else {
        return -1;
    }

    return 0;
}
